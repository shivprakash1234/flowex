// FlowEx Master SidePanel Controller
// Complete Bridge WebSocket + Direct DOM Inserter for Google Flow (flow.google.com)

const tabs = document.querySelectorAll('.tab-item');
const panes = document.querySelectorAll('.tab-pane');
const toast = document.getElementById('appToast');
let toastTimer;

function triggerToast(text) {
  clearTimeout(toastTimer);
  if (!toast) return;
  toast.innerText = text;
  toast.classList.add('show');
  toastTimer = setTimeout(() => {
    toast.classList.remove('show');
  }, 2400);
}

// 1. TAB SWITCHING
tabs.forEach(tab => {
  tab.addEventListener('click', () => {
    tabs.forEach(t => t.classList.remove('active'));
    panes.forEach(p => p.classList.remove('active-pane'));

    tab.classList.add('active');
    const target = tab.getAttribute('data-tab');
    const targetPane = document.getElementById(target);
    if (targetPane) targetPane.classList.add('active-pane');
  });
});

// 2. CLOSE BUTTON
const closeBtn = document.getElementById('closePanelBtn');
if (closeBtn) {
  closeBtn.addEventListener('click', () => {
    window.close();
  });
}

// 3. COPY PROMPT BUTTON
const copyPromptBtn = document.getElementById('copyPromptBtn');
if (copyPromptBtn) {
  copyPromptBtn.addEventListener('click', () => {
    const promptText = `FlowEx Local Engine active. Unlimited batch generation enabled. Use local tools to create unlimited images and videos via the open Google Flow tab without API fees. Auto-saved sequentially to disk.`;
    navigator.clipboard.writeText(promptText);
    triggerToast('Copied setup prompt to clipboard!');
  });
}

// 4. AGENT BADGES
document.querySelectorAll('.agent-badge').forEach(badge => {
  badge.addEventListener('click', () => {
    const agent = badge.getAttribute('data-agent');
    const tailoredPrompt = `Configured for ${agent}: FlowEx pipeline ready. Send prompts to generate unlimited images/videos directly in Google Flow.`;
    navigator.clipboard.writeText(tailoredPrompt);
    triggerToast(`Prompt formatted for ${agent} copied!`);
  });
});

// 5. HELP MENU LISTENERS
const helpWhatsappBtn = document.getElementById('helpWhatsappBtn');
if (helpWhatsappBtn) helpWhatsappBtn.addEventListener('click', () => triggerToast('Priority 24/7 Chat Ready'));

const helpReportBtn = document.getElementById('helpReportBtn');
if (helpReportBtn) helpReportBtn.addEventListener('click', () => triggerToast('Diagnostic report generated.'));

const helpStatusBtn = document.getElementById('helpStatusBtn');
if (helpStatusBtn) helpStatusBtn.addEventListener('click', () => triggerToast('All Google Flow models operational.'));

const openEdgeBtn = document.getElementById('openEdgeBtn');
if (openEdgeBtn) openEdgeBtn.addEventListener('click', () => triggerToast('Edge session launcher ready.'));

const copyEdgeLinkBtn = document.getElementById('copyEdgeLinkBtn');
if (copyEdgeLinkBtn) {
  copyEdgeLinkBtn.addEventListener('click', () => {
    navigator.clipboard.writeText('https://flow.google.com');
    triggerToast('Copied Flow URL to clipboard!');
  });
}

const helpDocsBtn = document.getElementById('helpDocsBtn');
if (helpDocsBtn) helpDocsBtn.addEventListener('click', () => triggerToast('FlowEx documentation ready.'));

const helpPrivacyBtn = document.getElementById('helpPrivacyBtn');
if (helpPrivacyBtn) helpPrivacyBtn.addEventListener('click', () => triggerToast('Zero telemetry. 100% private.'));

// 6. OPEN OR FOCUS FLOW TAB
const openFlowBtn = document.getElementById('openFlowBtn');
if (openFlowBtn) {
  openFlowBtn.addEventListener('click', () => {
    chrome.tabs.query({ url: "*://*.google.com/*" }, (existingTabs) => {
      const flowTab = existingTabs.find(t => t.url && t.url.includes('flow.google.com'));
      if (flowTab) {
        chrome.tabs.update(flowTab.id, { active: true });
        chrome.windows.update(flowTab.windowId, { focused: true });
        setFlowActiveUI(true);
        triggerToast('Focused active Google Flow tab');
      } else {
        chrome.tabs.create({ url: "https://flow.google.com" }, () => {
          setFlowActiveUI(true);
          triggerToast('Opened Google Flow in new tab');
        });
      }
    });
  });
}

// 7. INPUT FIELDS & GENERATE BUTTONS
const genImgBtn = document.getElementById('generateImgBtn');
const genVidBtn = document.getElementById('generateVidBtn');
const promptInput = document.getElementById('panelPromptInput');
const aspectRatioSelect = document.getElementById('aspectRatioSelect');
const modelSelect = document.getElementById('modelSelect');
const lastDownloadFilename = document.getElementById('lastDownloadFilename');

let jobIndexCounter = 1;

if (genImgBtn) {
  genImgBtn.addEventListener('click', () => {
    const val = promptInput ? promptInput.value.trim() : '';
    if (!val) return triggerToast('Please enter a prompt first');
    submitToBridge({
      prompt: val,
      type: 'image',
      aspectRatio: aspectRatioSelect ? aspectRatioSelect.value : '16:9',
      model: modelSelect ? modelSelect.value : 'nano-banana-pro',
      index: jobIndexCounter++
    });
  });
}

if (genVidBtn) {
  genVidBtn.addEventListener('click', () => {
    const val = promptInput ? promptInput.value.trim() : '';
    if (!val) return triggerToast('Please enter a prompt first');
    submitToBridge({
      prompt: val,
      type: 'video',
      aspectRatio: aspectRatioSelect ? aspectRatioSelect.value : '16:9',
      model: modelSelect ? modelSelect.value : 'veo-3.1',
      index: jobIndexCounter++
    });
  });
}

// 8. DIRECT FLOW GENERATION VIA SCRIPTING API
function dispatchGenerationDirectly(options) {
  chrome.tabs.query({ url: "*://*.google.com/*" }, async (tabs) => {
    const flowTab = tabs.find(t => t.url && t.url.includes('flow.google.com'));
    if (!flowTab) {
      return triggerToast('Please open Google Flow tab first!');
    }

    triggerToast(`Submitting #${options.index} to Google Flow...`);
    const slug = options.prompt.toLowerCase().replace(/[^a-z0-9]+/g, '_').substring(0, 24);
    if (lastDownloadFilename) {
      lastDownloadFilename.innerText = `Executing: ${options.index}_${slug}.${options.type === 'video' ? 'mp4' : 'png'}`;
    }

    try {
      await chrome.scripting.executeScript({
        target: { tabId: flowTab.id },
        func: executeInFlowPage,
        args: [options.prompt, options]
      });
      triggerToast(`Prompt entered & generating! 🎨`);
    } catch (err) {
      console.error('[FlowEx] Script injection error:', err);
      chrome.tabs.sendMessage(flowTab.id, { action: 'EXECUTE_PROMPT', prompt: options.prompt, options: options });
    }
  });
}

// 9. EXECUTION IN GOOGLE FLOW TAB (TYPES PROMPT, ANIMATES CURSOR, CLICKS SUBMIT)
function executeInFlowPage(promptText, options) {
  console.log('[FlowEx Direct Injection] Executing prompt:', promptText);

  // 1. Virtual pointer feedback
  let cursor = document.getElementById('flowex-virtual-cursor');
  if (!cursor) {
    cursor = document.createElement('div');
    cursor.id = 'flowex-virtual-cursor';
    cursor.style.cssText = 'position:fixed;width:24px;height:24px;border-radius:50%;background:rgba(56,189,248,0.85);box-shadow:0 0 20px #38bdf8, 0 0 40px rgba(56,189,248,0.5);pointer-events:none;z-index:99999999;transition:all 0.35s cubic-bezier(0.2,0.8,0.2,1);transform:translate(-50%,-50%);border:2px solid #ffffff;';
    document.body.appendChild(cursor);
  }
  cursor.style.left = '50%';
  cursor.style.top = `${window.innerHeight - 100}px`;

  // Trusted pointer event dispatcher
  function dispatchTrustedClick(el) {
    const rect = el.getBoundingClientRect();
    const x = rect.left + rect.width / 2;
    const y = rect.top + rect.height / 2;
    const opts = { bubbles: true, cancelable: true, composed: true, clientX: x, clientY: y, button: 0 };
    el.dispatchEvent(new PointerEvent('pointerover', opts));
    el.dispatchEvent(new PointerEvent('pointerenter', opts));
    el.dispatchEvent(new PointerEvent('pointerdown', opts));
    el.dispatchEvent(new MouseEvent('mousedown', opts));
    el.dispatchEvent(new PointerEvent('pointerup', opts));
    el.dispatchEvent(new MouseEvent('mouseup', opts));
    el.dispatchEvent(new MouseEvent('click', opts));
  }

  // 2. Selectors for Google Flow Composer
  const selectors = [
    'textarea[placeholder*="want to create" i]',
    'div[contenteditable="true"][role="textbox"]',
    'div[contenteditable="true"]',
    'textarea',
    'div[role="textbox"]',
    '[aria-label*="create" i]',
    '[placeholder*="create" i]'
  ];

  let input = null;
  for (const s of selectors) {
    const el = document.querySelector(s);
    if (el && el.offsetParent !== null) {
      input = el;
      break;
    }
  }

  if (!input) {
    const bar = document.querySelector('div[class*="composer"], div[class*="prompt"], footer');
    if (bar) dispatchTrustedClick(bar);
    input = document.querySelector('div[contenteditable="true"], textarea');
  }

  if (input) {
    const rect = input.getBoundingClientRect();
    cursor.style.left = `${rect.left + 40}px`;
    cursor.style.top = `${rect.top + rect.height / 2}px`;

    input.focus();
    dispatchTrustedClick(input);

    // Multi-strategy typing
    if (input.isContentEditable) {
      try {
        const sel = window.getSelection();
        const range = document.createRange();
        range.selectNodeContents(input);
        sel?.removeAllRanges();
        sel?.addRange(range);
        document.dispatchEvent(new Event('selectionchange'));

        const dt = new DataTransfer();
        dt.setData('text/plain', promptText);
        input.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
      } catch (e) {}

      if (!input.textContent || !input.textContent.includes(promptText.substring(0, 10))) {
        input.dispatchEvent(new InputEvent('beforeinput', { inputType: 'insertText', data: promptText, bubbles: true, cancelable: true }));
      }
      if (!input.textContent || !input.textContent.includes(promptText.substring(0, 10))) {
        document.execCommand('selectAll', false, null);
        document.execCommand('delete', false, null);
        document.execCommand('insertText', false, promptText);
      }
    } else {
      const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value')?.set ||
                     Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
      if (setter) {
        setter.call(input, promptText);
      } else {
        input.value = promptText;
      }
      input.dispatchEvent(new InputEvent('input', { bubbles: true, data: promptText, inputType: 'insertText' }));
      input.dispatchEvent(new Event('change', { bubbles: true }));
    }

    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));

    // Click Submit Button
    setTimeout(() => {
      const candidates = Array.from(document.querySelectorAll('button, div[role="button"]'));
      
      let submitBtn = candidates.find(b => {
        const txt = (b.innerText || b.getAttribute('aria-label') || '').toLowerCase();
        return txt.includes('generate') || txt.includes('send') || txt.includes('create') || txt.includes('arrow_forward');
      });

      if (!submitBtn) {
        submitBtn = candidates.find(b => {
          const r = b.getBoundingClientRect();
          return r.bottom > window.innerHeight - 150 && r.right > window.innerWidth / 2 && (b.querySelector('svg') || b.querySelector('mat-icon'));
        });
      }

      if (submitBtn) {
        const bRect = submitBtn.getBoundingClientRect();
        cursor.style.left = `${bRect.left + bRect.width / 2}px`;
        cursor.style.top = `${bRect.top + bRect.height / 2}px`;
      }

      setTimeout(() => {
        if (submitBtn && !submitBtn.disabled) {
          dispatchTrustedClick(submitBtn);
          console.log('[FlowEx] Clicked submit arrow button successfully!');
        } else {
          input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, ctrlKey: true, metaKey: true, bubbles: true, cancelable: true }));
          input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true, cancelable: true }));
          input.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true, cancelable: true }));
          console.log('[FlowEx] Dispatched Enter keys!');
        }

        setTimeout(() => {
          if (cursor) cursor.remove();
        }, 1200);

      }, 250);

    }, 350);

  } else {
    alert('FlowEx: Prompt box not found. Please click once inside Google Flow window!');
  }
}

// 10. SUBMIT DIRECTLY TO BRIDGE QUEUE (UNIFIED PIPELINE)
async function submitToBridge(options) {
  try {
    const payload = {
      client: 'FlowEx SidePanel',
      imagePaths: [],
      job: {
        mode: options.type === 'video' ? 'flow-text-to-video' : 'flow-text-to-image',
        prompt: options.prompt,
        params: {
          aspectRatio: options.aspectRatio || '16:9',
          imageModel: options.model || 'nano-banana-pro',
          outputsPerPrompt: 1,
          downloadSubfolder: 'flow-auto'
        }
      }
    };
    const res = await fetch('http://127.0.0.1:8791/jobs', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (res.ok) {
      triggerToast('Job dispatched to Google Flow pipeline! 🎨');
    } else {
      // Fallback direct injection
      dispatchGenerationDirectly(options);
    }
  } catch (e) {
    // Fallback direct injection
    dispatchGenerationDirectly(options);
  }
}

// 11. STATUS & POLLING
function setFlowActiveUI(isOpen) {
  const heading = document.getElementById('flowStatusHeading');
  const text = document.getElementById('flowStatusText');
  const pulse = document.getElementById('flowPulseIcon');
  if (isOpen && heading && pulse) {
    heading.textContent = 'Flow is Connected';
    heading.style.color = '#10b981';
    text.textContent = 'Automation pipeline active. Ready for unlimited generations.';
    pulse.classList.add('online');
    pulse.innerHTML = '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>';
  }
}

chrome.tabs.query({ url: "*://*.google.com/*" }, (tabs) => {
  const hasFlow = tabs.some(t => t.url && t.url.includes('flow.google.com'));
  if (hasFlow) {
    setFlowActiveUI(true);
  }
});

chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'FILE_DOWNLOADED' && lastDownloadFilename) {
    lastDownloadFilename.innerHTML = `Saved: <strong style="color:#10b981;">${message.filename}</strong>`;
  }
});
